# SeisSrcInv

A full waveform seismic source mechanism inversion package. This package takes Green's functions and real, observed seismograms and performs a Bayesian inversion. The package also allows for the inversion results to be plotted.