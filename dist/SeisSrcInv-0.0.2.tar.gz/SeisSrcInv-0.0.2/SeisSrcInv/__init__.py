name = "SeisSrcInv"
__version__ = "0.1"
__description__ = "SeisSrcInv - A full waveform seismic source mechanism inversion package"
__license__ = "MIT"
__author__ = "Tom Hudson"
__email__ = "tsh37@cantab.net"
import inversion as inversion
import plot as plot
